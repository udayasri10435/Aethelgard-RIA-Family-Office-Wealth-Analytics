import React from 'react';
import { ClientHousehold } from '../../types/wealth';
import { calculateBrinsonFachlerAttribution, calculateRiskAdjustedAnalytics } from '../../utils/financialCalculations';

interface QuarterlyReportingStudioProps {
  household: ClientHousehold;
  onPrintReport: () => void;
}

export const QuarterlyReportingStudio: React.FC<QuarterlyReportingStudioProps> = ({
  household,
  onPrintReport,
}) => {
  const attribution = calculateBrinsonFachlerAttribution(household, '60_40_BLENDED');
  const riskMetrics = calculateRiskAdjustedAnalytics(household, attribution.benchmarkTotalReturn);

  const quarterlyFee = (household.totalAUM * (household.annualFeeBps / 10000)) / 4;

  return (
    <div className="space-y-6">
      {/* Studio Controls Header (Hidden during Print) */}
      <div className="no-print border border-slate-800 bg-slate-900/60 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>Quarterly Performance Review (QPR) Studio</span>
              <span aria-hidden="true">·</span>
              <span>GIPS & SEC Rule 206(4)-1 Compliant Statement</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-100">
              Institutional Client Reporting & Investment Committee Dossier
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Publication-grade quarterly report ready for distribution to family office trustees, investment committees, and regulatory audits.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onPrintReport}
              className="px-4 py-2 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm flex items-center gap-2"
            >
              <span>🖨️ Print / Save as PDF</span>
            </button>
          </div>
        </div>
      </div>

      {/* Printable Report Document Sheet */}
      <div className="bg-slate-900 text-slate-100 print:bg-white print:text-slate-900 border border-slate-800 print:border-none rounded-lg p-8 sm:p-12 space-y-8 shadow-2xl">
        {/* Document Header */}
        <div className="border-b-2 border-slate-700 print:border-slate-300 pb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 print:text-amber-700 font-mono">
              Aethelgard Wealth Management, RIA · Registered Investment Advisor
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight mt-1">
              Quarterly Portfolio Performance &amp; Attribution Review
            </h1>
            <p className="text-sm text-slate-400 print:text-slate-600 mt-1">
              Third Calendar Quarter Ended September 30, 2026 (Q3 2026)
            </p>
          </div>

          <div className="text-right text-xs text-slate-400 print:text-slate-600 font-mono space-y-0.5">
            <div>CONFIDENTIAL REPORT</div>
            <div>Prepared for: {household.primaryContact}</div>
            <div>Account: {household.accountNumber}</div>
            <div>Custodian: {household.custodian}</div>
          </div>
        </div>

        {/* Executive Mandate & Value Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-950/80 print:bg-slate-100 border border-slate-800 print:border-slate-300">
          <div>
            <div className="text-xs text-slate-400 print:text-slate-600">Ending Market Value</div>
            <div className="text-xl font-bold font-mono text-slate-100 print:text-slate-900 mt-0.5">
              ${(household.totalAUM / 1000000).toFixed(2)}M
            </div>
            <div className="text-[10px] text-slate-500 font-mono">USD Net Equity</div>
          </div>

          <div>
            <div className="text-xs text-slate-400 print:text-slate-600">12-Month Net Return (TWR)</div>
            <div className="text-xl font-bold font-mono text-emerald-400 print:text-emerald-700 mt-0.5">
              +{household.oneYearReturnPct.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Benchmark: +13.85%</div>
          </div>

          <div>
            <div className="text-xs text-slate-400 print:text-slate-600">Annualized Active Alpha</div>
            <div className="text-xl font-bold font-mono text-amber-300 print:text-amber-700 mt-0.5">
              +{attribution.totalActiveReturn.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Over Policy Benchmark</div>
          </div>

          <div>
            <div className="text-xs text-slate-400 print:text-slate-600">Risk Profile / Mandate</div>
            <div className="text-sm font-bold text-slate-200 print:text-slate-800 mt-1 truncate">
              {household.riskMandate}
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Annual Fee: {household.annualFeeBps} bps</div>
          </div>
        </div>

        {/* Multi-Period Performance Track Record */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            1. Multi-Period Returns &amp; Benchmark Comparisons
          </h3>
          <table className="w-full text-xs font-mono border border-slate-800 print:border-slate-300">
            <thead className="bg-slate-950 print:bg-slate-200 text-slate-400 print:text-slate-700">
              <tr>
                <th className="py-2 px-3 text-left font-sans">Performance Measure</th>
                <th className="py-2 px-3 text-right">YTD 2026</th>
                <th className="py-2 px-3 text-right">1-Year Trailing</th>
                <th className="py-2 px-3 text-right">3-Year Ann.</th>
                <th className="py-2 px-3 text-right">5-Year Ann.</th>
                <th className="py-2 px-3 text-right">Since Inception</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 print:divide-slate-300">
              <tr className="bg-slate-900/60 print:bg-white font-bold text-slate-100 print:text-slate-900">
                <td className="py-2.5 px-3 font-sans">{household.householdName} (Net of Fees)</td>
                <td className="py-2.5 px-3 text-right text-emerald-400 print:text-emerald-700">+{household.ytdReturnPct.toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-right text-emerald-400 print:text-emerald-700">+{household.oneYearReturnPct.toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-right">+{household.threeYearReturnPct.toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-right">+{household.fiveYearReturnPct.toFixed(2)}%</td>
                <td className="py-2.5 px-3 text-right text-amber-300 print:text-amber-800">+{household.twrReturnPct.toFixed(2)}%</td>
              </tr>
              <tr className="text-slate-400 print:text-slate-700">
                <td className="py-2 px-3 font-sans">60/40 Institutional Policy Benchmark</td>
                <td className="py-2 px-3 text-right">+10.40%</td>
                <td className="py-2 px-3 text-right">+13.85%</td>
                <td className="py-2 px-3 text-right">+8.40%</td>
                <td className="py-2 px-3 text-right">+9.95%</td>
                <td className="py-2 px-3 text-right">+10.20%</td>
              </tr>
              <tr className="text-slate-400 print:text-slate-700">
                <td className="py-2 px-3 font-sans">S&P 500 Total Return Index</td>
                <td className="py-2 px-3 text-right">+14.80%</td>
                <td className="py-2 px-3 text-right">+19.20%</td>
                <td className="py-2 px-3 text-right">+11.60%</td>
                <td className="py-2 px-3 text-right">+14.10%</td>
                <td className="py-2 px-3 text-right">+13.90%</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Brinson-Fachler Attribution Breakdown */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            2. Brinson-Fachler Excess Alpha Attribution Summary
          </h3>
          <table className="w-full text-xs font-mono border border-slate-800 print:border-slate-300">
            <thead className="bg-slate-950 print:bg-slate-200 text-slate-400 print:text-slate-700">
              <tr>
                <th className="py-2 px-3 text-left font-sans">Asset Category</th>
                <th className="py-2 px-2 text-right">Portfolio Wt</th>
                <th className="py-2 px-2 text-right">Benchmark Wt</th>
                <th className="py-2 px-2 text-right">Allocation Effect</th>
                <th className="py-2 px-2 text-right">Selection Effect</th>
                <th className="py-2 px-3 text-right">Total Active Value</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 print:divide-slate-300">
              {attribution.rows.map((r) => (
                <tr key={r.category} className="hover:bg-slate-800/30 print:hover:bg-transparent">
                  <td className="py-2 px-3 font-sans text-slate-200 print:text-slate-800">{r.category}</td>
                  <td className="py-2 px-2 text-right text-slate-400 print:text-slate-600">{r.portfolioWeight.toFixed(1)}%</td>
                  <td className="py-2 px-2 text-right text-slate-400 print:text-slate-600">{r.benchmarkWeight.toFixed(1)}%</td>
                  <td className={`py-2 px-2 text-right ${r.allocationEffect >= 0 ? 'text-amber-300 print:text-amber-700 font-semibold' : 'text-slate-400'}`}>
                    {r.allocationEffect >= 0 ? `+${r.allocationEffect.toFixed(2)}%` : `${r.allocationEffect.toFixed(2)}%`}
                  </td>
                  <td className={`py-2 px-2 text-right ${r.selectionEffect >= 0 ? 'text-emerald-400 print:text-emerald-700 font-semibold' : 'text-slate-400'}`}>
                    {r.selectionEffect >= 0 ? `+${r.selectionEffect.toFixed(2)}%` : `${r.selectionEffect.toFixed(2)}%`}
                  </td>
                  <td className={`py-2 px-3 text-right font-bold ${r.totalEffect >= 0 ? 'text-emerald-400 print:text-emerald-800' : 'text-rose-400 print:text-rose-700'}`}>
                    {r.totalEffect >= 0 ? `+${r.totalEffect.toFixed(2)}%` : `${r.totalEffect.toFixed(2)}%`}
                  </td>
                </tr>
              ))}
              <tr className="bg-slate-950 print:bg-slate-100 font-bold border-t-2 border-slate-700 print:border-slate-400 text-slate-100 print:text-slate-900">
                <td className="py-2 px-3 font-sans">Active Alpha Total</td>
                <td className="py-2 px-2 text-right">100.0%</td>
                <td className="py-2 px-2 text-right">100.0%</td>
                <td className="py-2 px-2 text-right text-amber-300 print:text-amber-700">+{attribution.totalAllocationEffect.toFixed(2)}%</td>
                <td className="py-2 px-2 text-right text-emerald-400 print:text-emerald-700">+{attribution.totalSelectionEffect.toFixed(2)}%</td>
                <td className="py-2 px-3 text-right text-emerald-400 print:text-emerald-800">+{attribution.totalActiveReturn.toFixed(2)}%</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Risk & Volatility Ratios */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            3. Risk-Adjusted Statistical Ratios (GIPS Standards)
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 text-xs font-mono">
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Sharpe Ratio</div>
              <div className="text-sm font-bold mt-0.5">{riskMetrics.annualizedSharpeRatio}</div>
            </div>
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Sortino Ratio</div>
              <div className="text-sm font-bold mt-0.5">{riskMetrics.annualizedSortinoRatio}</div>
            </div>
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Jensen Alpha</div>
              <div className="text-sm font-bold mt-0.5">+{riskMetrics.jensensAlpha}%</div>
            </div>
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Beta to Policy</div>
              <div className="text-sm font-bold mt-0.5">{riskMetrics.beta}</div>
            </div>
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Tracking Error</div>
              <div className="text-sm font-bold mt-0.5">{riskMetrics.trackingError}%</div>
            </div>
            <div className="border border-slate-800 print:border-slate-300 p-2.5 rounded bg-slate-950/40 print:bg-slate-50">
              <div className="text-[10px] text-slate-400 print:text-slate-500 font-sans">Max Drawdown</div>
              <div className="text-sm font-bold mt-0.5 text-rose-400 print:text-rose-700">-{riskMetrics.maxDrawdown}%</div>
            </div>
          </div>
        </div>

        {/* SEC Form ADV Part 2A Billing Transparency Disclosure */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 print:text-slate-800">
            4. Advisory Fee Schedule &amp; Custodian Billing Statement
          </h3>
          <div className="text-xs p-4 rounded bg-slate-950/60 print:bg-slate-50 border border-slate-800 print:border-slate-300 space-y-2">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-slate-300 print:text-slate-800 font-semibold font-sans">
                Agreed Contractual Advisory Fee: {household.annualFeeBps} basis points (0.{household.annualFeeBps}% per annum)
              </span>
              <span className="font-mono text-slate-400 print:text-slate-600">
                Direct Debit Authorized via {household.custodian}
              </span>
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-slate-400 print:text-slate-600 pt-1 border-t border-slate-800 print:border-slate-200">
              <span>Quarterly Billing Fee Billed (Q3 2026):</span>
              <span className="font-mono font-bold text-slate-100 print:text-slate-900">
                ${quarterlyFee.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
              </span>
            </div>
          </div>
        </div>

        {/* SEC / FINRA Mandatory Disclosures & Footnotes */}
        <div className="border-t border-slate-800 print:border-slate-300 pt-4 text-[11px] text-slate-500 print:text-slate-600 space-y-1.5 leading-relaxed">
          <p>
            <strong>Regulatory &amp; Fiduciary Notice:</strong> Aethelgard Wealth Management is an SEC-registered investment adviser. Registration does not imply a certain level of skill or training. Past performance is no guarantee of future returns. Investments are subject to market risks, including the potential loss of principal.
          </p>
          <p>
            <strong>Performance Standards (GIPS):</strong> Performance figures are presented net of all actual investment management fees, custodial expenses, and trading commissions. Time-Weighted Returns (TWR) reflect the reinvestment of dividends, interest, and capital gains distributions.
          </p>
          <p>
            <strong>Attribution Methodology:</strong> Benchmark attribution utilizes the Brinson-Fachler methodology. Benchmark returns are calculated using public indices and do not reflect management fees. The 60/40 Institutional Policy Benchmark represents 60% MSCI ACWI Net and 40% Bloomberg US Aggregate Bond Index.
          </p>
        </div>
      </div>
    </div>
  );
};
