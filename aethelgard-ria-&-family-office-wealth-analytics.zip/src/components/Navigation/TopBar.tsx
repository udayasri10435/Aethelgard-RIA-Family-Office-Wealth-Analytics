import React from 'react';
import { ClientHousehold } from '../../types/wealth';

export type NavTab = 'overview' | 'attribution' | 'rebalancing' | 'compliance' | 'reporting';

interface TopBarProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  households: ClientHousehold[];
  selectedHouseholdId: string;
  onHouseholdChange: (id: string) => void;
  openBreachCount: number;
  onPrintReport: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentTab,
  onTabChange,
  households,
  selectedHouseholdId,
  onHouseholdChange,
  openBreachCount,
  onPrintReport,
}) => {
  const selectedHousehold = households.find((h) => h.id === selectedHouseholdId) || households[0];

  return (
    <header className="no-print sticky top-0 z-50 bg-slate-950/95 backdrop-blur border-b border-slate-800">
      {/* Strict 3-Zone Top Bar Contract */}
      <div className="max-w-[1440px] mx-auto px-6 h-16 flex items-center justify-between gap-6">
        {/* Zone 1: Single text element wordmark in display face */}
        <div className="flex items-center gap-3 shrink-0">
          <span className="text-base font-semibold tracking-tight text-slate-100 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-400 rotate-45 inline-block"></span>
            Aethelgard Wealth Analytics
          </span>
        </div>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium">
          <button
            onClick={() => onTabChange('overview')}
            className={`transition-colors py-1 cursor-pointer whitespace-nowrap ${
              currentTab === 'overview'
                ? 'text-amber-400 border-b-2 border-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Portfolio Overview
          </button>
          <button
            onClick={() => onTabChange('attribution')}
            className={`transition-colors py-1 cursor-pointer whitespace-nowrap ${
              currentTab === 'attribution'
                ? 'text-amber-400 border-b-2 border-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Brinson Attribution
          </button>
          <button
            onClick={() => onTabChange('rebalancing')}
            className={`transition-colors py-1 cursor-pointer whitespace-nowrap ${
              currentTab === 'rebalancing'
                ? 'text-amber-400 border-b-2 border-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Tax-Aware Rebalancing
          </button>
          <button
            onClick={() => onTabChange('compliance')}
            className={`transition-colors py-1 cursor-pointer whitespace-nowrap flex items-center gap-2 ${
              currentTab === 'compliance'
                ? 'text-amber-400 border-b-2 border-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Compliance & Audit</span>
            {openBreachCount > 0 && (
              <span className="font-mono text-xs px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                {openBreachCount}
              </span>
            )}
          </button>
          <button
            onClick={() => onTabChange('reporting')}
            className={`transition-colors py-1 cursor-pointer whitespace-nowrap ${
              currentTab === 'reporting'
                ? 'text-amber-400 border-b-2 border-amber-400 font-semibold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Quarterly Reporting
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Household / Entity Selector */}
          <div className="flex items-center gap-2">
            <label htmlFor="household-select" className="text-xs text-slate-400 hidden sm:inline">
              Mandate:
            </label>
            <select
              id="household-select"
              value={selectedHouseholdId}
              onChange={(e) => onHouseholdChange(e.target.value)}
              className="bg-slate-900 border border-slate-700 hover:border-slate-600 text-xs text-slate-100 rounded px-3 py-1.5 focus:outline-none focus:border-amber-400 max-w-[210px] sm:max-w-[260px] truncate cursor-pointer"
            >
              {households.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.householdName} (${(h.totalAUM / 1000000).toFixed(1)}M)
                </option>
              ))}
            </select>
          </div>

          {/* Print / Export Report Action */}
          <button
            onClick={onPrintReport}
            className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
          >
            Export QPR PDF
          </button>
        </div>
      </div>

      {/* Mobile Nav row */}
      <div className="lg:hidden flex items-center justify-between px-4 py-2 border-t border-slate-900 overflow-x-auto text-xs gap-3">
        <button
          onClick={() => onTabChange('overview')}
          className={`whitespace-nowrap ${currentTab === 'overview' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
        >
          Overview
        </button>
        <button
          onClick={() => onTabChange('attribution')}
          className={`whitespace-nowrap ${currentTab === 'attribution' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
        >
          Attribution
        </button>
        <button
          onClick={() => onTabChange('rebalancing')}
          className={`whitespace-nowrap ${currentTab === 'rebalancing' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
        >
          Rebalance
        </button>
        <button
          onClick={() => onTabChange('compliance')}
          className={`whitespace-nowrap ${currentTab === 'compliance' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
        >
          Compliance ({openBreachCount})
        </button>
        <button
          onClick={() => onTabChange('reporting')}
          className={`whitespace-nowrap ${currentTab === 'reporting' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
        >
          Reporting
        </button>
      </div>
    </header>
  );
};
