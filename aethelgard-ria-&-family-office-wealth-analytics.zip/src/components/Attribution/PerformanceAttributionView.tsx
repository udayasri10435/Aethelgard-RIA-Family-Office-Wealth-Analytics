import React, { useState } from 'react';
import { ClientHousehold } from '../../types/wealth';
import {
  BENCHMARK_NAMES,
  calculateBrinsonFachlerAttribution,
  calculateRiskAdjustedAnalytics,
} from '../../utils/financialCalculations';
import { FinancialChart } from '../Common/FinancialChart';
import { HISTORICAL_PERFORMANCE_DATA } from '../../data/seedData';

interface PerformanceAttributionViewProps {
  household: ClientHousehold;
}

export const PerformanceAttributionView: React.FC<PerformanceAttributionViewProps> = ({ household }) => {
  const [selectedBenchmark, setSelectedBenchmark] = useState<string>('60_40_BLENDED');

  const attribution = calculateBrinsonFachlerAttribution(household, selectedBenchmark);
  const riskMetrics = calculateRiskAdjustedAnalytics(household, attribution.benchmarkTotalReturn);

  return (
    <div className="space-y-6">
      {/* Header & Benchmark Selector */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>Performance Attribution Engine</span>
              <span aria-hidden="true">·</span>
              <span>Brinson-Fachler Multi-Asset Decomposition</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-100">
              Active Excess Return & Risk-Adjusted Analytics
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Dissects portfolio active return into pure asset allocation decisions versus security selection skill against policy benchmarks.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <label htmlFor="benchmark-select" className="text-xs text-slate-300 font-medium whitespace-nowrap">
              Policy Benchmark:
            </label>
            <select
              id="benchmark-select"
              value={selectedBenchmark}
              onChange={(e) => setSelectedBenchmark(e.target.value)}
              className="bg-slate-950 border border-slate-700 text-xs text-slate-100 rounded px-3 py-1.5 focus:outline-none focus:border-amber-400 cursor-pointer"
            >
              <option value="60_40_BLENDED">60/40 Institutional Blended (60% MSCI ACWI / 40% Agg)</option>
              <option value="SP500_TR">S&P 500 Total Return Index</option>
            </select>
          </div>
        </div>
      </div>

      {/* Attribution High-Level Alpha Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Portfolio Return (TWR)</div>
          <div className="text-xl font-bold font-mono tabular-nums text-slate-100 mt-1">
            +{attribution.portfolioReturn.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            Net of all fees & expenses
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Benchmark Return</div>
          <div className="text-xl font-bold font-mono tabular-nums text-sky-400 mt-1">
            +{attribution.benchmarkTotalReturn.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5 truncate" title={BENCHMARK_NAMES[selectedBenchmark as keyof typeof BENCHMARK_NAMES]}>
            {selectedBenchmark === '60_40_BLENDED' ? '60/40 Blended' : 'S&P 500 TR'}
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Total Active Alpha (Excess)</div>
          <div className={`text-xl font-bold font-mono tabular-nums mt-1 ${
            attribution.totalActiveReturn >= 0 ? 'text-emerald-400' : 'text-rose-400'
          }`}>
            {attribution.totalActiveReturn >= 0 ? '+' : ''}{attribution.totalActiveReturn.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            {((attribution.totalActiveReturn) * 100).toFixed(0)} basis points
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Primary Alpha Driver</div>
          <div className="text-base font-bold text-amber-300 mt-1">
            {attribution.totalSelectionEffect > attribution.totalAllocationEffect
              ? 'Security Selection'
              : 'Asset Allocation'}
          </div>
          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
            Selection: +{attribution.totalSelectionEffect.toFixed(2)}% · Alloc: +{attribution.totalAllocationEffect.toFixed(2)}%
          </div>
        </div>
      </div>

      {/* Brinson-Fachler Attribution Table */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Brinson-Fachler Attribution Breakdown
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Allocation Effect = (w_i - W_i) × (R_i - R_b) · Selection Effect = W_i × (r_i - R_i) · Interaction = (w_i - W_i) × (r_i - R_i)
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Units: % Annualized
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                <th className="py-2.5 px-3">Asset Category</th>
                <th className="py-2.5 px-2 text-right">Port. Wt (w)</th>
                <th className="py-2.5 px-2 text-right">Bench. Wt (W)</th>
                <th className="py-2.5 px-2 text-right">Active Wt</th>
                <th className="py-2.5 px-2 text-right">Port. Ret (r)</th>
                <th className="py-2.5 px-2 text-right">Bench. Ret (R)</th>
                <th className="py-2.5 px-2 text-right text-amber-300">Allocation Effect</th>
                <th className="py-2.5 px-2 text-right text-emerald-300">Selection Effect</th>
                <th className="py-2.5 px-2 text-right text-indigo-300">Interaction</th>
                <th className="py-2.5 px-3 text-right font-bold text-slate-200">Total Value Added</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {attribution.rows.map((row) => {
                const activeWeight = row.portfolioWeight - row.benchmarkWeight;
                return (
                  <tr key={row.category} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                      {row.category}
                    </td>
                    <td className="py-2.5 px-2 text-right text-slate-300">
                      {row.portfolioWeight.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-2 text-right text-slate-400">
                      {row.benchmarkWeight.toFixed(1)}%
                    </td>
                    <td className={`py-2.5 px-2 text-right ${
                      activeWeight > 0 ? 'text-amber-400' : activeWeight < 0 ? 'text-sky-400' : 'text-slate-500'
                    }`}>
                      {activeWeight > 0 ? `+${activeWeight.toFixed(1)}%` : `${activeWeight.toFixed(1)}%`}
                    </td>
                    <td className="py-2.5 px-2 text-right text-slate-200">
                      {row.portfolioReturn >= 0 ? `+${row.portfolioReturn.toFixed(1)}%` : `${row.portfolioReturn.toFixed(1)}%`}
                    </td>
                    <td className="py-2.5 px-2 text-right text-slate-400">
                      {row.benchmarkReturn >= 0 ? `+${row.benchmarkReturn.toFixed(1)}%` : `${row.benchmarkReturn.toFixed(1)}%`}
                    </td>
                    {/* Allocation Effect */}
                    <td className={`py-2.5 px-2 text-right font-semibold ${
                      row.allocationEffect >= 0 ? 'text-amber-400' : 'text-rose-400'
                    }`}>
                      {row.allocationEffect >= 0 ? `+${row.allocationEffect.toFixed(2)}%` : `${row.allocationEffect.toFixed(2)}%`}
                    </td>
                    {/* Selection Effect */}
                    <td className={`py-2.5 px-2 text-right font-semibold ${
                      row.selectionEffect >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {row.selectionEffect >= 0 ? `+${row.selectionEffect.toFixed(2)}%` : `${row.selectionEffect.toFixed(2)}%`}
                    </td>
                    {/* Interaction Effect */}
                    <td className={`py-2.5 px-2 text-right ${
                      row.interactionEffect >= 0 ? 'text-indigo-400' : 'text-rose-400'
                    }`}>
                      {row.interactionEffect >= 0 ? `+${row.interactionEffect.toFixed(2)}%` : `${row.interactionEffect.toFixed(2)}%`}
                    </td>
                    {/* Total Value Added */}
                    <td className={`py-2.5 px-3 text-right font-bold ${
                      row.totalEffect >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}>
                      {row.totalEffect >= 0 ? `+${row.totalEffect.toFixed(2)}%` : `${row.totalEffect.toFixed(2)}%`}
                    </td>
                  </tr>
                );
              })}

              {/* Summary Totals Row */}
              <tr className="bg-slate-950 font-bold border-t-2 border-slate-700 text-slate-100">
                <td className="py-3 px-3 font-sans">
                  Total Portfolio Active Alpha
                </td>
                <td className="py-3 px-2 text-right">100.0%</td>
                <td className="py-3 px-2 text-right">100.0%</td>
                <td className="py-3 px-2 text-right text-slate-400">0.0%</td>
                <td className="py-3 px-2 text-right text-emerald-400">+{attribution.portfolioReturn.toFixed(2)}%</td>
                <td className="py-3 px-2 text-right text-sky-400">+{attribution.benchmarkTotalReturn.toFixed(2)}%</td>
                <td className="py-3 px-2 text-right text-amber-400 font-mono">
                  {attribution.totalAllocationEffect >= 0 ? '+' : ''}{attribution.totalAllocationEffect.toFixed(2)}%
                </td>
                <td className="py-3 px-2 text-right text-emerald-400 font-mono">
                  {attribution.totalSelectionEffect >= 0 ? '+' : ''}{attribution.totalSelectionEffect.toFixed(2)}%
                </td>
                <td className="py-3 px-2 text-right text-indigo-400 font-mono">
                  {attribution.totalInteractionEffect >= 0 ? '+' : ''}{attribution.totalInteractionEffect.toFixed(2)}%
                </td>
                <td className="py-3 px-3 text-right text-emerald-300 font-mono text-sm">
                  {attribution.totalActiveReturn >= 0 ? '+' : ''}{attribution.totalActiveReturn.toFixed(2)}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Historical Performance Time Series Visualizer */}
      <FinancialChart
        data={HISTORICAL_PERFORMANCE_DATA}
        portfolioName={household.householdName.split(' ')[0] + ' Trust'}
        benchmarkName="60/40 Institutional Policy"
        secondaryBenchmarkName="S&P 500 Total Return"
      />

      {/* Comprehensive Risk-Adjusted Analytics Grid */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5">
        <div className="border-b border-slate-800 pb-3 mb-4">
          <h3 className="text-sm font-semibold text-slate-100">
            Institutional Risk-Adjusted Ratios (CFA / GIPS Standards)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Calibrated against 3-month US Treasury risk-free rate (4.25%) over 36 trailing months
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Sharpe Ratio</div>
            <div className="text-lg font-bold font-mono text-amber-300 mt-1">
              {riskMetrics.annualizedSharpeRatio}
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Benchmark: 0.75</div>
          </div>

          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Sortino Ratio</div>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
              {riskMetrics.annualizedSortinoRatio}
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Downside StDev: 8.4%</div>
          </div>

          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Jensen's Alpha</div>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
              +{riskMetrics.jensensAlpha}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">CAPM Risk-Adjusted</div>
          </div>

          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Portfolio Beta (β)</div>
            <div className="text-lg font-bold font-mono text-slate-200 mt-1">
              {riskMetrics.beta}
            </div>
            <div className="text-[10px] text-slate-500 font-mono">To Policy Benchmark</div>
          </div>

          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Tracking Error</div>
            <div className="text-lg font-bold font-mono text-slate-200 mt-1">
              {riskMetrics.trackingError}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Info Ratio: {riskMetrics.informationRatio}</div>
          </div>

          <div className="border border-slate-800 bg-slate-950 p-3 rounded">
            <div className="text-[11px] text-slate-400">Max Drawdown</div>
            <div className="text-lg font-bold font-mono text-rose-400 mt-1">
              -{riskMetrics.maxDrawdown}%
            </div>
            <div className="text-[10px] text-slate-500 font-mono">Calmar: {riskMetrics.calmarRatio}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
