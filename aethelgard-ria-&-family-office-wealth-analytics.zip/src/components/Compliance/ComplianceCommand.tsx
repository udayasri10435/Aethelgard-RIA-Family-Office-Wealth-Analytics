import React, { useState } from 'react';
import { AuditLogEntry, ClientHousehold, ComplianceRuleBreach } from '../../types/wealth';

interface ComplianceCommandProps {
  household: ClientHousehold;
  breaches: ComplianceRuleBreach[];
  auditLogs: AuditLogEntry[];
  onResolveBreach: (breachId: string, notes: string) => void;
  onAddAuditEntry: (action: string, details: string) => void;
  onRevalidateIPS: () => void;
}

export const ComplianceCommand: React.FC<ComplianceCommandProps> = ({
  household,
  breaches,
  auditLogs,
  onResolveBreach,
  onAddAuditEntry,
  onRevalidateIPS,
}) => {
  const [selectedBreachForOverride, setSelectedBreachForOverride] = useState<ComplianceRuleBreach | null>(null);
  const [overrideNote, setOverrideNote] = useState<string>('');
  const [newAuditAction, setNewAuditAction] = useState<string>('');
  const [newAuditDetails, setNewAuditDetails] = useState<string>('');
  const [showAddLogModal, setShowAddLogModal] = useState<boolean>(false);

  const handleConfirmOverride = () => {
    if (!selectedBreachForOverride || !overrideNote.trim()) return;
    onResolveBreach(selectedBreachForOverride.id, overrideNote);
    setSelectedBreachForOverride(null);
    setOverrideNote('');
  };

  const handleCreateAuditLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuditAction.trim() || !newAuditDetails.trim()) return;
    onAddAuditEntry(newAuditAction, newAuditDetails);
    setNewAuditAction('');
    setNewAuditDetails('');
    setShowAddLogModal(false);
  };

  const openBreaches = breaches.filter((b) => b.status === 'OPEN_BREACH');
  const resolvedBreaches = breaches.filter((b) => b.status === 'OVERRIDE_APPROVED' || b.status === 'RESOLVED');

  // Calculate annual advisory fee breakdown for Form ADV Part 2A
  const grossFeeDollars = (household.totalAUM * (household.annualFeeBps / 10000));
  const quarterlyFeeDollars = grossFeeDollars / 4;

  return (
    <div className="space-y-6">
      {/* Compliance Command Header */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>SEC Rule 206(4)-7 & FINRA Rule 2111 Fiduciary Command</span>
              <span aria-hidden="true">·</span>
              <span>SEC Reg BI & Rule 17a-4 Books & Records</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-100">
              Regulatory Compliance, Mandate Surveillance & Audit
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Continuous supervisory oversight monitoring Investment Policy Statement (IPS) adherence, suitability verification, and immutable trade audit logs.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onRevalidateIPS}
              className="px-3.5 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
            >
              Attest Annual IPS Review
            </button>
            <button
              onClick={() => setShowAddLogModal(true)}
              className="px-3.5 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors whitespace-nowrap cursor-pointer"
            >
              + Log Supervisory Note
            </button>
          </div>
        </div>
      </div>

      {/* Compliance Summary Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Open Mandate Breaches</div>
          <div className={`text-xl font-bold font-mono tabular-nums mt-1 ${
            openBreaches.length > 0 ? 'text-rose-400' : 'text-emerald-400'
          }`}>
            {openBreaches.length} {openBreaches.length === 0 ? 'Nominal' : 'Active'}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            {resolvedBreaches.length} CCO overrides archived
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Annual IPS Attestation</div>
          <div className="text-lg font-bold font-mono text-slate-100 mt-1">
            {household.lastIPSReviewDate}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            FINRA Rule 2111 Suitability
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Form ADV Fee Audit</div>
          <div className="text-lg font-bold font-mono text-amber-300 mt-1">
            {household.annualFeeBps} bps ($
            {(quarterlyFeeDollars / 1000).toFixed(1)}k/qtr)
          </div>
          <div className="text-[11px] text-emerald-400 font-mono mt-0.5">
            0 Billing Discrepancies
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Books & Records Status</div>
          <div className="text-lg font-bold text-emerald-400 mt-1">
            WORM Compliant
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            SEC Rule 17a-4 Immutable
          </div>
        </div>
      </div>

      {/* Active Compliance Breaches & IPS Surveillance */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Active IPS Mandate Breaches & Risk Violations
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Automated algorithmic detection of concentration violations, liquidity depletion, and wash-sale prohibitions
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Real-Time Engine: SEC Rule 206(4)-7
          </span>
        </div>

        {openBreaches.length === 0 ? (
          <div className="py-6 text-center border border-dashed border-slate-800/80 rounded-lg text-emerald-400 text-xs">
            No open compliance breaches detected. Portfolio fully adheres to all Investment Policy Statement (IPS) guidelines.
          </div>
        ) : (
          <div className="space-y-3">
            {openBreaches.map((breach) => (
              <div
                key={breach.id}
                className="border border-rose-500/30 bg-rose-950/20 p-4 rounded-lg flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                      {breach.severity === 'HIGH_ALERT' ? 'HIGH ALERT' : 'WARNING'}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">{breach.regulatoryReference}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100">{breach.title}</h4>
                  <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                    {breach.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setSelectedBreachForOverride(breach)}
                    className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Authorize CCO Override
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Resolved / Overridden Breaches Archive */}
        {resolvedBreaches.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Supervisory Overrides & Resolved Exceptions ({resolvedBreaches.length})
            </h4>
            <div className="space-y-2">
              {resolvedBreaches.map((b) => (
                <div key={b.id} className="text-xs p-3 rounded bg-slate-950/60 border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <span className="text-slate-300 font-medium">{b.title}</span>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Override Justification: &quot;{b.overrideNotes}&quot; (Signed by {b.overrideBy})
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 shrink-0">
                    APPROVED EXCEPTION
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Form ADV Part 2A Fee & Billing Reconciliation Audit */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5">
        <div className="border-b border-slate-800 pb-3 mb-4">
          <h3 className="text-sm font-semibold text-slate-100">
            SEC Form ADV Part 2A Fee Schedule & Direct Debit Reconciliation
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Quarterly advisory fee calculation audited against client contract terms and custodian debit authorization
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="text-slate-400">Advisory Fee Schedule Tier</div>
            <div className="text-base font-bold font-mono text-slate-100">{household.annualFeeBps} bps (0.{household.annualFeeBps}%)</div>
            <div className="text-slate-500 text-[11px]">Contractual tier: $50M - $250M Institutional</div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="text-slate-400">Calculated Q3 2026 Advisory Fee</div>
            <div className="text-base font-bold font-mono text-amber-300">
              ${quarterlyFeeDollars.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className="text-slate-500 text-[11px]">Formula: (AUM × Fee Bps) ÷ 4</div>
          </div>

          <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
            <div className="text-slate-400">Custodian Direct Debit Reconciliation</div>
            <div className="text-base font-bold text-emerald-400">Verified & Reconciled</div>
            <div className="text-slate-500 text-[11px]">{household.custodian} Account #{household.accountNumber}</div>
          </div>
        </div>
      </div>

      {/* SEC Rule 17a-4 Books & Records Immutable Audit Log */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              SEC Rule 17a-4 WORM Immutable Audit Ledger
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Tamper-evident timestamped ledger of trade blotters, rebalances, and supervisory compliance reviews
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Audit Retention: 7 Years Mandated
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                <th className="py-2 px-3">Audit ID / Timestamp</th>
                <th className="py-2 px-3">Supervisory Actor</th>
                <th className="py-2 px-3">Action Type</th>
                <th className="py-2 px-3">Regulatory Code</th>
                <th className="py-2 px-3">Event Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {auditLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    <span className="font-semibold text-slate-200">{log.id}</span>
                    <div className="text-[10px] text-slate-500">{log.timestamp}</div>
                  </td>
                  <td className="py-2.5 px-3 font-sans whitespace-nowrap">
                    <div className="font-medium text-slate-200">{log.actor}</div>
                    <div className="text-[10px] text-slate-400">{log.actorRole}</div>
                  </td>
                  <td className="py-2.5 px-3 font-sans">
                    <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                      {log.action}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400 whitespace-nowrap">
                    {log.regulatoryCode}
                  </td>
                  <td className="py-2.5 px-3 font-sans text-slate-300 text-[11px] max-w-md">
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CCO Supervisory Override Modal */}
      {selectedBreachForOverride && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-lg p-6 max-w-lg w-full space-y-4 shadow-xl">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100">
                Authorize Chief Compliance Officer Override
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                SEC Rule 206(4)-7 requires written fiduciary justification for any exception to client Investment Policy Statements.
              </p>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs space-y-1">
              <div className="font-semibold text-rose-300">{selectedBreachForOverride.title}</div>
              <div className="text-slate-400">{selectedBreachForOverride.description}</div>
            </div>

            <div className="space-y-1">
              <label htmlFor="override-note-input" className="text-xs text-slate-300 font-medium">
                Mandatory CCO Justification & Written Rationale:
              </label>
              <textarea
                id="override-note-input"
                rows={3}
                value={overrideNote}
                onChange={(e) => setOverrideNote(e.target.value)}
                placeholder="e.g., Client requested tax deferral due to zero basis lot; client signed concentration acknowledgment letter on file dated 2026-09-28."
                className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setSelectedBreachForOverride(null)}
                className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmOverride}
                disabled={!overrideNote.trim()}
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 disabled:cursor-not-allowed rounded transition-colors cursor-pointer"
              >
                Sign & Archive Override
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Supervisory Audit Note Modal */}
      {showAddLogModal && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <form onSubmit={handleCreateAuditLog} className="bg-slate-900 border border-slate-700 rounded-lg p-6 max-w-lg w-full space-y-4 shadow-xl">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100">
                Log SEC Rule 17a-4 Supervisory Inspection
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Appends an immutable entry to the institutional compliance ledger for regulatory audit inspections.
              </p>
            </div>

            <div className="space-y-1">
              <label htmlFor="audit-action-type" className="text-xs text-slate-300 font-medium">
                Action / Inspection Type:
              </label>
              <input
                id="audit-action-type"
                type="text"
                value={newAuditAction}
                onChange={(e) => setNewAuditAction(e.target.value)}
                placeholder="e.g. SUITABILITY_RECHECK_VERIFIED"
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div className="space-y-1">
              <label htmlFor="supervisory-details" className="text-xs text-slate-300 font-medium">
                Supervisory Observation Details:
              </label>
              <textarea
                id="supervisory-details"
                rows={3}
                value={newAuditDetails}
                onChange={(e) => setNewAuditDetails(e.target.value)}
                placeholder="Record exact fiduciary observations, review findings, or trade allocation fairness notes..."
                className="w-full bg-slate-950 border border-slate-700 rounded p-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-400"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowAddLogModal(false)}
                className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-slate-200 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors cursor-pointer"
              >
                Record Entry
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
