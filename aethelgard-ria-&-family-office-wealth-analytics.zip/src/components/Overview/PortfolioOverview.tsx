import React, { useState } from 'react';
import { AssetCategory, ClientHousehold, HoldingLot } from '../../types/wealth';

interface PortfolioOverviewProps {
  household: ClientHousehold;
  openBreachesCount: number;
  onNavigateToTab: (tab: 'attribution' | 'rebalancing' | 'compliance' | 'reporting') => void;
  onQuickHarvestLot: (lot: HoldingLot) => void;
}

export const PortfolioOverview: React.FC<PortfolioOverviewProps> = ({
  household,
  openBreachesCount,
  onNavigateToTab,
  onQuickHarvestLot,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Calculate current allocation per category
  const categoryTotals: Record<AssetCategory, number> = {
    'US Large Cap Equity': 0,
    'US Small/Mid Cap': 0,
    'International Developed Equity': 0,
    'Emerging Markets Equity': 0,
    'Core Fixed Income': 0,
    'Municipal Bonds': 0,
    'Liquid Treasuries & Cash': 0,
    'Private Real Assets & Alts': 0,
  };

  household.holdings.forEach((h) => {
    categoryTotals[h.category] += h.marketValue;
  });

  // Filter holdings
  const filteredHoldings = household.holdings.filter((lot) => {
    const matchesSearch =
      lot.ticker.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lot.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === 'ALL' || lot.category === selectedCategory;
    return matchesSearch && matchesCat;
  });

  const liquidCashPct = (categoryTotals['Liquid Treasuries & Cash'] / household.totalAUM) * 100;

  return (
    <div className="space-y-6">
      {/* Entity Profile Banner */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-1">
              <span>{household.entityType}</span>
              <span aria-hidden="true">·</span>
              <span>Custodian: {household.custodian}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-slate-300">Acct #{household.accountNumber}</span>
              <span aria-hidden="true">·</span>
              <span>Inception: {household.inceptionDate}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-100">
              {household.householdName}
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 mt-1">
              <span>Managing Trustee: <strong className="text-slate-200">{household.primaryContact}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Lead Advisor: <strong className="text-slate-200">{household.advisorName}</strong></span>
              <span aria-hidden="true">·</span>
              <span>Advisory Fee: <strong className="font-mono text-amber-300">{household.annualFeeBps} bps</strong></span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigateToTab('rebalancing')}
              className="px-4 py-2 text-xs font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
            >
              Analyze Rebalance Drift
            </button>
            <button
              onClick={() => onNavigateToTab('compliance')}
              className={`px-4 py-2 text-xs font-semibold rounded border transition-colors whitespace-nowrap cursor-pointer ${
                openBreachesCount > 0
                  ? 'border-rose-500/50 bg-rose-950/40 text-rose-300 hover:bg-rose-900/50'
                  : 'border-slate-700 bg-slate-800/80 text-slate-300 hover:bg-slate-700'
              }`}
            >
              {openBreachesCount > 0 ? `IPS Breaches (${openBreachesCount})` : 'Compliance Status: Compliant'}
            </button>
          </div>
        </div>
      </div>

      {/* Institutional KPI Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Total Portfolio AUM</div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-100 mt-1">
            ${(household.totalAUM / 1000000).toFixed(2)}M
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            ${household.totalAUM.toLocaleString()}
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">TWR 1-Yr Net Return</div>
          <div className="text-lg font-bold font-mono tabular-nums text-emerald-400 mt-1">
            +{household.oneYearReturnPct.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            Benchmark: +13.85%
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Money-Weighted (IRR)</div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-100 mt-1">
            +{household.mwrReturnPct.toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            Net Cash Flow Adjusted
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Unrealized Capital P&L</div>
          <div className="text-lg font-bold font-mono tabular-nums text-emerald-400 mt-1">
            +${(household.unrealizedGainsTotal / 1000000).toFixed(2)}M
          </div>
          <div className="text-[11px] text-rose-400 font-mono mt-0.5">
            Loss Lots: ${(Math.abs(household.unrealizedLossesTotal) / 1000).toFixed(0)}k
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Liquid Cash Reserves</div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-100 mt-1">
            {liquidCashPct.toFixed(2)}%
          </div>
          <div className={`text-[11px] font-mono mt-0.5 ${liquidCashPct < 2.5 ? 'text-rose-400 font-semibold' : 'text-slate-500'}`}>
            ${(categoryTotals['Liquid Treasuries & Cash'] / 1000000).toFixed(2)}M {liquidCashPct < 2.5 ? '(! Low)' : ''}
          </div>
        </div>

        <div className="border border-slate-800 bg-slate-900/50 p-4 rounded-lg">
          <div className="text-xs text-slate-400">Mandate & IPS</div>
          <div className="text-xs font-semibold text-amber-300 mt-1 truncate" title={household.riskMandate}>
            {household.riskMandate}
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            Reviewed: {household.lastIPSReviewDate}
          </div>
        </div>
      </div>

      {/* Asset Allocation vs Target Policy Matrix */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Policy Asset Allocation & Tolerance Drift
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Investment Policy Statement (IPS) target weighting bands with rebalance triggers
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Tolerance Band: $\pm$2.0% to 5.0%
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                <th className="py-2.5 px-3">Asset Category</th>
                <th className="py-2.5 px-3 text-right">Target %</th>
                <th className="py-2.5 px-3 text-right">Allowed Band</th>
                <th className="py-2.5 px-3 text-right">Current Value</th>
                <th className="py-2.5 px-3 text-right">Current %</th>
                <th className="py-2.5 px-3 text-right">Active Drift</th>
                <th className="py-2.5 px-3 text-center">Mandate Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {household.targets.map((tgt) => {
                const currentVal = categoryTotals[tgt.category] || 0;
                const currentPct = household.totalAUM > 0 ? (currentVal / household.totalAUM) * 100 : 0;
                const driftPct = currentPct - tgt.targetPct;
                const isBreaching = currentPct < tgt.minTolerancePct || currentPct > tgt.maxTolerancePct;

                return (
                  <tr key={tgt.category} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                      {tgt.category}
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-300">
                      {tgt.targetPct.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-500">
                      {tgt.minTolerancePct.toFixed(1)}% – {tgt.maxTolerancePct.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-200 font-semibold">
                      ${(currentVal / 1000000).toFixed(2)}M
                    </td>
                    <td className="py-2.5 px-3 text-right text-slate-100 font-semibold">
                      {currentPct.toFixed(1)}%
                    </td>
                    <td className={`py-2.5 px-3 text-right font-semibold ${
                      Math.abs(driftPct) < 0.5
                        ? 'text-slate-400'
                        : driftPct > 0
                        ? 'text-amber-400'
                        : 'text-sky-400'
                    }`}>
                      {driftPct >= 0 ? `+${driftPct.toFixed(1)}%` : `${driftPct.toFixed(1)}%`}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      {isBreaching ? (
                        <span className="text-[11px] px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                          Drift Breach
                        </span>
                      ) : (
                        <span className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-emerald-400">
                          In Range
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Holdings Lot-Level Detail Grid */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Tax-Lot Holdings & Security Ledger
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Specific lot acquisition dates, cost basis accounting, and tax-loss harvesting status
            </p>
          </div>

          {/* Search & Category Filter */}
          <div className="flex flex-wrap items-center gap-2">
            <input
              type="text"
              placeholder="Search ticker or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-950 border border-slate-800 px-3 py-1.5 text-xs text-slate-100 rounded focus:outline-none focus:border-amber-400 placeholder:text-slate-600 w-44"
            />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-slate-950 border border-slate-800 px-3 py-1.5 text-xs text-slate-200 rounded focus:outline-none focus:border-amber-400"
            >
              <option value="ALL">All Asset Categories</option>
              {Object.keys(categoryTotals).map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                <th className="py-2.5 px-3">Ticker / Security</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">Shares</th>
                <th className="py-2.5 px-3 text-right">Cost Basis</th>
                <th className="py-2.5 px-3 text-right">Current Price</th>
                <th className="py-2.5 px-3 text-right">Market Value</th>
                <th className="py-2.5 px-3 text-right">Weight %</th>
                <th className="py-2.5 px-3 text-right">Unrealized P&L</th>
                <th className="py-2.5 px-3 text-center">Tax Term</th>
                <th className="py-2.5 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredHoldings.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-6 text-center text-slate-500 font-sans">
                    No holdings match your search filters.
                  </td>
                </tr>
              ) : (
                filteredHoldings.map((lot) => {
                  const weightPct = (lot.marketValue / household.totalAUM) * 100;
                  const isConcentrated = weightPct > 7.5;
                  const isLoss = lot.unrealizedGainLoss < 0;

                  return (
                    <tr key={lot.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3">
                        <div className="font-sans font-semibold text-slate-100 flex items-center gap-2">
                          <span>{lot.ticker}</span>
                          {isConcentrated && (
                            <span className="text-[10px] px-1.5 py-0.2 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded">
                              Conc. Limit &gt;7.5%
                            </span>
                          )}
                        </div>
                        <div className="font-sans text-[11px] text-slate-400 truncate max-w-[160px]">
                          {lot.name}
                        </div>
                      </td>
                      <td className="py-2.5 px-3 font-sans text-slate-400 text-[11px]">
                        {lot.category}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-200">
                        {lot.shares.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-400">
                        ${lot.costBasisPerShare.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-100 font-semibold">
                        ${lot.currentPrice.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-100 font-semibold">
                        ${lot.marketValue.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-300">
                        {weightPct.toFixed(2)}%
                      </td>
                      <td className={`py-2.5 px-3 text-right font-semibold ${
                        isLoss ? 'text-rose-400' : 'text-emerald-400'
                      }`}>
                        <div>{isLoss ? '-' : '+'}${Math.abs(lot.unrealizedGainLoss).toLocaleString()}</div>
                        <div className="text-[10px] opacity-80">
                          {lot.unrealizedGainLossPct >= 0 ? '+' : ''}{lot.unrealizedGainLossPct.toFixed(2)}%
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-center">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${
                          lot.isLongTerm ? 'bg-slate-800 text-slate-300' : 'bg-amber-950/60 text-amber-300'
                        }`}>
                          {lot.isLongTerm ? 'Long-Term' : 'Short-Term'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {isLoss ? (
                          <button
                            onClick={() => onQuickHarvestLot(lot)}
                            className="px-2.5 py-1 text-[11px] font-sans font-medium text-amber-300 bg-amber-950/60 hover:bg-amber-900/60 border border-amber-500/40 rounded transition-colors whitespace-nowrap cursor-pointer"
                          >
                            Harvest Loss
                          </button>
                        ) : (
                          <button
                            onClick={() => onNavigateToTab('rebalancing')}
                            className="px-2 py-1 text-[11px] font-sans text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
                          >
                            Rebalance
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
