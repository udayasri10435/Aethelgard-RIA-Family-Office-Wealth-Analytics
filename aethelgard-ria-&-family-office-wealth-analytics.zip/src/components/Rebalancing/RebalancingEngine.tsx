import React, { useState } from 'react';
import { ClientHousehold, TradeOrder } from '../../types/wealth';
import { generateRebalancingProposal } from '../../utils/financialCalculations';

interface RebalancingEngineProps {
  household: ClientHousehold;
  onExecuteTradeBatch: (orders: TradeOrder[]) => void;
  stagedOrders: TradeOrder[];
  setStagedOrders: React.Dispatch<React.SetStateAction<TradeOrder[]>>;
}

export const RebalancingEngine: React.FC<RebalancingEngineProps> = ({
  household,
  onExecuteTradeBatch,
  stagedOrders,
  setStagedOrders,
}) => {
  const [rebalMode, setRebalMode] = useState<
    'TARGET_ALIGNMENT' | 'TAX_LOSS_HARVEST_ONLY' | 'CASH_DEPLOYMENT' | 'CASH_WITHDRAWAL'
  >('TARGET_ALIGNMENT');

  const [cashDeltaInput, setCashDeltaInput] = useState<string>('1000000');
  const [useSubstituteEtfs, setUseSubstituteEtfs] = useState<boolean>(true);
  const [respectWashSale, setRespectWashSale] = useState<boolean>(true);
  const [executionSuccessNotice, setExecutionSuccessNotice] = useState<string | null>(null);

  // Calculate rebalancing proposal
  const cashDeltaNum =
    rebalMode === 'CASH_DEPLOYMENT'
      ? Math.abs(Number(cashDeltaInput) || 0)
      : rebalMode === 'CASH_WITHDRAWAL'
      ? -Math.abs(Number(cashDeltaInput) || 0)
      : 0;

  const proposal = generateRebalancingProposal(household, {
    mode: rebalMode,
    cashDelta: cashDeltaNum,
    respectWashSaleRule: respectWashSale,
    useSubstituteEtfs: useSubstituteEtfs,
  });

  const handleGenerateOrders = () => {
    setStagedOrders(proposal.generatedOrders);
    setExecutionSuccessNotice(null);
  };

  const handleApproveAll = () => {
    setStagedOrders((prev) =>
      prev.map((o) => ({ ...o, status: 'APPROVED' }))
    );
  };

  const handleExecuteBatch = () => {
    const approvedOrders = stagedOrders.filter((o) => o.status === 'APPROVED' || o.status === 'STAGED');
    if (approvedOrders.length === 0) return;

    onExecuteTradeBatch(approvedOrders);
    setExecutionSuccessNotice(
      `Successfully routed and executed ${approvedOrders.length} orders across ${household.custodian}. Regulatory confirmation archived in SEC Rule 17a-4 audit log.`
    );
    setStagedOrders([]);
  };

  const handleRemoveOrder = (id: string) => {
    setStagedOrders((prev) => prev.filter((o) => o.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Header & Mode Selector */}
      <div className="border border-slate-800 bg-slate-900/60 rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-400 mb-1">
              <span>Tax-Aware Portfolio Rebalancing Engine</span>
              <span aria-hidden="true">·</span>
              <span>Wash Sale Guard & Multi-Custodian FIX Blotter</span>
            </div>
            <h2 className="text-xl font-bold tracking-tight text-slate-100">
              Model Alignment & Tax-Loss Harvesting Blotter
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Maintains IPS target weights, minimizes capital gains realization, and isolates harvesting opportunities with automated proxy ETF substitution.
            </p>
          </div>

          {/* Rebalance Mode Selector */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
            <button
              onClick={() => {
                setRebalMode('TARGET_ALIGNMENT');
                setExecutionSuccessNotice(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                rebalMode === 'TARGET_ALIGNMENT'
                  ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Target Alignment
            </button>
            <button
              onClick={() => {
                setRebalMode('TAX_LOSS_HARVEST_ONLY');
                setExecutionSuccessNotice(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                rebalMode === 'TAX_LOSS_HARVEST_ONLY'
                  ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tax-Loss Harvest (TLH)
            </button>
            <button
              onClick={() => {
                setRebalMode('CASH_DEPLOYMENT');
                setExecutionSuccessNotice(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                rebalMode === 'CASH_DEPLOYMENT'
                  ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cash Inflow (+Deposit)
            </button>
            <button
              onClick={() => {
                setRebalMode('CASH_WITHDRAWAL');
                setExecutionSuccessNotice(null);
              }}
              className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap cursor-pointer ${
                rebalMode === 'CASH_WITHDRAWAL'
                  ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Cash Outflow (-Distribution)
            </button>
          </div>
        </div>

        {/* Dynamic Controls Bar depending on mode */}
        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap items-center gap-6">
            {(rebalMode === 'CASH_DEPLOYMENT' || rebalMode === 'CASH_WITHDRAWAL') && (
              <div className="flex items-center gap-2">
                <span className="text-slate-400 font-medium">
                  {rebalMode === 'CASH_DEPLOYMENT' ? 'Inflow Deposit Amount ($):' : 'Liquidation Amount ($):'}
                </span>
                <input
                  type="number"
                  value={cashDeltaInput}
                  onChange={(e) => setCashDeltaInput(e.target.value)}
                  step="50000"
                  className="bg-slate-950 border border-slate-700 px-2.5 py-1 text-slate-100 font-mono rounded w-36 focus:outline-none focus:border-amber-400"
                />
              </div>
            )}

            <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={respectWashSale}
                onChange={(e) => setRespectWashSale(e.target.checked)}
                className="rounded border-slate-700 text-amber-400 focus:ring-0"
              />
              <span>Enforce IRS 30-Day Wash-Sale Lockout</span>
            </label>

            <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={useSubstituteEtfs}
                onChange={(e) => setUseSubstituteEtfs(e.target.checked)}
                className="rounded border-slate-700 text-amber-400 focus:ring-0"
              />
              <span>Substitute Proxy ETFs (Preserve Market Beta)</span>
            </label>
          </div>

          <button
            onClick={handleGenerateOrders}
            className="px-4 py-2 font-semibold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
          >
            Generate Staged Trade Orders
          </button>
        </div>
      </div>

      {executionSuccessNotice && (
        <div className="border border-emerald-500/40 bg-emerald-950/40 p-4 rounded-lg text-xs text-emerald-200 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
            <span>{executionSuccessNotice}</span>
          </div>
          <button
            onClick={() => setExecutionSuccessNotice(null)}
            className="text-emerald-400 hover:text-emerald-200 cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Drift & Tolerance Matrix */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-100">
              Pre-Trade Drift & Tolerance Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Calculates deviation against target model and required dollar adjustment to return to neutral policy
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">
            Rebalancing Threshold: $\pm$3.0% or &gt;$25,000
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                <th className="py-2.5 px-3">Asset Category</th>
                <th className="py-2.5 px-2 text-right">Current Value</th>
                <th className="py-2.5 px-2 text-right">Current %</th>
                <th className="py-2.5 px-2 text-right">Target %</th>
                <th className="py-2.5 px-2 text-right">Tolerance Band</th>
                <th className="py-2.5 px-2 text-right">Active Drift</th>
                <th className="py-2.5 px-3 text-right">Required Delta ($)</th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {proposal.driftAnalysis.map((d) => (
                <tr key={d.category} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-3 font-sans font-medium text-slate-200">
                    {d.category}
                  </td>
                  <td className="py-2.5 px-2 text-right text-slate-300">
                    ${(d.currentValue / 1000000).toFixed(2)}M
                  </td>
                  <td className="py-2.5 px-2 text-right text-slate-100 font-semibold">
                    {d.currentPct.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-2 text-right text-slate-400">
                    {d.targetPct.toFixed(1)}%
                  </td>
                  <td className="py-2.5 px-2 text-right text-slate-500">
                    {d.minTolerancePct.toFixed(1)}% – {d.maxTolerancePct.toFixed(1)}%
                  </td>
                  <td className={`py-2.5 px-2 text-right font-semibold ${
                    d.isBreachingTolerance ? 'text-rose-400' : Math.abs(d.driftPct) > 1.5 ? 'text-amber-400' : 'text-slate-400'
                  }`}>
                    {d.driftPct >= 0 ? `+${d.driftPct.toFixed(1)}%` : `${d.driftPct.toFixed(1)}%`}
                  </td>
                  <td className={`py-2.5 px-3 text-right font-bold ${
                    d.deltaValue > 0 ? 'text-emerald-400' : d.deltaValue < 0 ? 'text-rose-400' : 'text-slate-400'
                  }`}>
                    {d.deltaValue > 0 ? `+$${d.deltaValue.toLocaleString()}` : `-$${Math.abs(d.deltaValue).toLocaleString()}`}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {d.isBreachingTolerance ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/40">
                        Breach
                      </span>
                    ) : Math.abs(d.deltaValue) > 25000 ? (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                        Rebalance
                      </span>
                    ) : (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                        In Target
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Trade Blotter & Execution Console */}
      <div className="border border-slate-800 bg-slate-900/50 rounded-lg p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-100">
                FIX Protocol Order Blotter & Execution Queue
              </h3>
              <span className="font-mono text-xs px-2 py-0.5 rounded bg-slate-800 text-amber-300">
                {stagedOrders.length} Orders Staged
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              SEC Rule 17a-4 pre-trade verification · Best Execution routing across {household.custodian}
            </p>
          </div>

          {stagedOrders.length > 0 && (
            <div className="flex items-center gap-2">
              <button
                onClick={handleApproveAll}
                className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded transition-colors cursor-pointer"
              >
                Approve All Orders
              </button>
              <button
                onClick={handleExecuteBatch}
                className="px-4 py-1.5 text-xs font-semibold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded transition-colors whitespace-nowrap cursor-pointer shadow-sm"
              >
                Execute Batch & Commit
              </button>
            </div>
          )}
        </div>

        {stagedOrders.length === 0 ? (
          <div className="py-8 text-center border border-dashed border-slate-800 rounded-lg space-y-2">
            <p className="text-sm text-slate-400 font-medium">No trade orders currently staged in blotter.</p>
            <p className="text-xs text-slate-500">
              Click &quot;Generate Staged Trade Orders&quot; above to preview automated rebalance or tax-loss harvesting execution.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 font-medium text-left">
                  <th className="py-2.5 px-3">Order ID / Ticker</th>
                  <th className="py-2.5 px-2">Action</th>
                  <th className="py-2.5 px-2 text-right">Shares</th>
                  <th className="py-2.5 px-2 text-right">Est. Price</th>
                  <th className="py-2.5 px-2 text-right">Total Principal</th>
                  <th className="py-2.5 px-2">Tax Lot Impact</th>
                  <th className="py-2.5 px-2">Routing Broker</th>
                  <th className="py-2.5 px-2">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {stagedOrders.map((order) => {
                  const isBuy = order.action === 'BUY';
                  return (
                    <tr key={order.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-2.5 px-3">
                        <div className="font-sans font-semibold text-slate-100 flex items-center gap-1.5">
                          <span>{order.ticker}</span>
                          <span className="text-[10px] text-slate-500 font-mono">({order.id})</span>
                        </div>
                        <div className="font-sans text-[11px] text-slate-400 max-w-[220px] truncate" title={order.reason}>
                          {order.reason}
                        </div>
                      </td>
                      <td className="py-2.5 px-2">
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                          isBuy ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/40' : 'bg-rose-950/60 text-rose-400 border border-rose-500/40'
                        }`}>
                          {order.action}
                        </span>
                      </td>
                      <td className="py-2.5 px-2 text-right text-slate-200">
                        {order.shares.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-2 text-right text-slate-400">
                        ${order.price.toFixed(2)}
                      </td>
                      <td className="py-2.5 px-2 text-right text-slate-100 font-semibold">
                        ${order.estimatedValue.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-2 font-sans text-[11px]">
                        {order.taxLotImpact ? (
                          order.taxLotImpact.type === 'TAX_LOSS_HARVEST' ? (
                            <span className="text-amber-300">
                              Harvest Loss (-${Math.abs(order.taxLotImpact.estimatedPnl).toLocaleString()})
                            </span>
                          ) : (
                            <span className="text-slate-300">
                              Capital Gain (+${order.taxLotImpact.estimatedPnl.toLocaleString()})
                            </span>
                          )
                        ) : (
                          <span className="text-slate-500">New Position</span>
                        )}
                      </td>
                      <td className="py-2.5 px-2 font-sans text-slate-400 text-[11px] truncate max-w-[120px]">
                        {order.custodian}
                      </td>
                      <td className="py-2.5 px-2">
                        <span className={`text-[10px] px-2 py-0.5 rounded ${
                          order.status === 'APPROVED'
                            ? 'bg-sky-950/60 text-sky-400 border border-sky-500/40'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <button
                          onClick={() => handleRemoveOrder(order.id)}
                          className="text-slate-500 hover:text-rose-400 font-sans text-xs cursor-pointer"
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
