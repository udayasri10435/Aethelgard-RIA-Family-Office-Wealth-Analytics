import React, { useState } from 'react';
import { HistoricalPerformancePoint } from '../../types/wealth';

interface FinancialChartProps {
  data: HistoricalPerformancePoint[];
  portfolioName: string;
  benchmarkName: string;
  secondaryBenchmarkName?: string;
}

export const FinancialChart: React.FC<FinancialChartProps> = ({
  data,
  portfolioName,
  benchmarkName,
  secondaryBenchmarkName = 'S&P 500 TR',
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const [activeMetric, setActiveMetric] = useState<'cumulative' | 'drawdown'>('cumulative');

  if (!data || data.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center border border-slate-800 rounded-lg bg-slate-900/40 text-slate-500 text-sm">
        No performance history available for this entity.
      </div>
    );
  }

  const width = 800;
  const height = 280;
  const padding = { top: 20, right: 30, bottom: 35, left: 45 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;

  // Compute min/max for scale
  let minVal = 0;
  let maxVal = 25;

  if (activeMetric === 'cumulative') {
    const allVals = data.flatMap((d) => [
      d.portfolioCumulativePct,
      d.benchmarkCumulativePct,
      d.secondaryBenchmarkPct || 0,
    ]);
    minVal = Math.min(-2, Math.floor(Math.min(...allVals) - 1));
    maxVal = Math.ceil(Math.max(...allVals) + 2);
  } else {
    const drawdowns = data.map((d) => d.drawdownPct);
    minVal = Math.floor(Math.min(...drawdowns, -4));
    maxVal = 1;
  }

  const valRange = maxVal - minVal || 1;

  const getX = (index: number) => padding.left + (index / (data.length - 1)) * chartW;
  const getY = (val: number) => padding.top + chartH - ((val - minVal) / valRange) * chartH;

  // Build SVG path strings
  const portPath = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(activeMetric === 'cumulative' ? d.portfolioCumulativePct : d.drawdownPct)}`)
    .join(' ');

  const benchPath = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.benchmarkCumulativePct)}`)
    .join(' ');

  const secBenchPath = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i)} ${getY(d.secondaryBenchmarkPct || 0)}`)
    .join(' ');

  // Gradient area fill for portfolio
  const portAreaPath = `${portPath} L ${getX(data.length - 1)} ${getY(minVal)} L ${getX(0)} ${getY(minVal)} Z`;

  // Drawdown filled area
  const zeroY = getY(0);
  const drawdownArea = `${portPath} L ${getX(data.length - 1)} ${zeroY} L ${getX(0)} ${zeroY} Z`;

  const activePoint = hoveredIdx !== null ? data[hoveredIdx] : data[data.length - 1];
  const excessOverBenchmark = (activePoint.portfolioCumulativePct - activePoint.benchmarkCumulativePct).toFixed(2);

  // Y-axis ticks
  const yTicks = [minVal, minVal + valRange * 0.33, minVal + valRange * 0.66, maxVal].map((v) => Number(v.toFixed(1)));

  return (
    <div className="border border-slate-800 rounded-lg bg-slate-900/60 p-5 space-y-4">
      {/* Chart Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-100 tracking-tight">
              Historical Cumulative Total Return (TWR)
            </h3>
            <span className="text-xs text-slate-400 font-mono">12-Month Net of Advisory Fees</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
            <span>Period: Oct 2025 – Sep 2026</span>
            <span aria-hidden="true">·</span>
            <span>Currency: USD ($)</span>
            <span aria-hidden="true">·</span>
            <span className="text-emerald-400 font-mono tabular-nums">
              Cumulative Alpha: {Number(excessOverBenchmark) >= 0 ? `+${excessOverBenchmark}%` : `${excessOverBenchmark}%`}
            </span>
          </div>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-md border border-slate-800 text-xs">
          <button
            onClick={() => setActiveMetric('cumulative')}
            className={`px-3 py-1 font-medium rounded transition-colors ${
              activeMetric === 'cumulative'
                ? 'bg-slate-800 text-amber-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Cumulative Return
          </button>
          <button
            onClick={() => setActiveMetric('drawdown')}
            className={`px-3 py-1 font-medium rounded transition-colors ${
              activeMetric === 'drawdown'
                ? 'bg-slate-800 text-rose-300 font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Drawdown (%)
          </button>
        </div>
      </div>

      {/* Legend & Hovered Metric Inspection Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 text-xs bg-slate-950/70 px-3 py-2 rounded border border-slate-800/60">
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-0.5 bg-amber-400 rounded-full inline-block"></span>
            <span className="text-slate-200 font-medium">{portfolioName}</span>
            <span className="font-mono tabular-nums text-amber-400 font-semibold">
              {activeMetric === 'cumulative'
                ? `${activePoint.portfolioCumulativePct >= 0 ? '+' : ''}${activePoint.portfolioCumulativePct.toFixed(2)}%`
                : `${activePoint.drawdownPct.toFixed(2)}%`}
            </span>
          </div>

          {activeMetric === 'cumulative' && (
            <>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-0.5 bg-sky-400 rounded-full inline-block"></span>
                <span className="text-slate-400">{benchmarkName}</span>
                <span className="font-mono tabular-nums text-sky-400">
                  +{activePoint.benchmarkCumulativePct.toFixed(2)}%
                </span>
              </div>

              <div className="flex items-center gap-1.5 hidden md:flex">
                <span className="w-3 h-0.5 bg-slate-500 rounded-full inline-block"></span>
                <span className="text-slate-400">{secondaryBenchmarkName}</span>
                <span className="font-mono tabular-nums text-slate-300">
                  +{activePoint.secondaryBenchmarkPct.toFixed(2)}%
                </span>
              </div>
            </>
          )}
        </div>

        <div className="text-slate-400 font-mono text-[11px]">
          Observation Date:{' '}
          <span className="text-slate-200 font-semibold">{activePoint.date}</span> (AUM: $
          {(activePoint.portfolioValue / 1000000).toFixed(1)}M)
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full aspect-[800/280] overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-full select-none"
          onMouseLeave={() => setHoveredIdx(null)}
        >
          <defs>
            <linearGradient id="portGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.25" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="drawdownGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#f43f5e" stopOpacity="0.3" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          {yTicks.map((tick, i) => (
            <g key={i}>
              <line
                x1={padding.left}
                y1={getY(tick)}
                x2={width - padding.right}
                y2={getY(tick)}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="3 3"
              />
              <text
                x={padding.left - 8}
                y={getY(tick) + 3}
                fill="#64748b"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor="end"
              >
                {tick >= 0 ? `+${tick}%` : `${tick}%`}
              </text>
            </g>
          ))}

          {/* Zero baseline */}
          {minVal <= 0 && maxVal >= 0 && (
            <line
              x1={padding.left}
              y1={getY(0)}
              x2={width - padding.right}
              y2={getY(0)}
              stroke="#334155"
              strokeWidth="1.2"
            />
          )}

          {/* X Axis labels */}
          {data.map((d, i) => {
            if (i % 2 !== 0 && i !== data.length - 1) return null;
            return (
              <text
                key={i}
                x={getX(i)}
                y={height - 10}
                fill="#64748b"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor="middle"
              >
                {d.date.split(' ')[0]}
              </text>
            );
          })}

          {/* Curves */}
          {activeMetric === 'cumulative' ? (
            <>
              {/* Secondary Benchmark */}
              <path d={secBenchPath} fill="none" stroke="#475569" strokeWidth="1.5" strokeDasharray="4 2" />
              {/* Primary Benchmark */}
              <path d={benchPath} fill="none" stroke="#38bdf8" strokeWidth="2" />
              {/* Portfolio Area Fill */}
              <path d={portAreaPath} fill="url(#portGradient)" />
              {/* Portfolio Primary Line */}
              <path d={portPath} fill="none" stroke="#f59e0b" strokeWidth="2.5" />
            </>
          ) : (
            <>
              <path d={drawdownArea} fill="url(#drawdownGradient)" />
              <path d={portPath} fill="none" stroke="#f43f5e" strokeWidth="2" />
            </>
          )}

          {/* Hover interaction overlay columns */}
          {data.map((_, i) => (
            <rect
              key={i}
              x={getX(i) - (chartW / (data.length - 1)) / 2}
              y={padding.top}
              width={chartW / (data.length - 1)}
              height={chartH}
              fill="transparent"
              className="cursor-crosshair"
              onMouseEnter={() => setHoveredIdx(i)}
            />
          ))}

          {/* Active hover indicator */}
          {hoveredIdx !== null && (
            <g>
              <line
                x1={getX(hoveredIdx)}
                y1={padding.top}
                x2={getX(hoveredIdx)}
                y2={height - padding.bottom}
                stroke="#94a3b8"
                strokeWidth="1"
                strokeDasharray="2 2"
              />
              <circle
                cx={getX(hoveredIdx)}
                cy={getY(activeMetric === 'cumulative' ? data[hoveredIdx].portfolioCumulativePct : data[hoveredIdx].drawdownPct)}
                r="4.5"
                fill="#f59e0b"
                stroke="#0f172a"
                strokeWidth="2"
              />
            </g>
          )}
        </svg>
      </div>
    </div>
  );
};
