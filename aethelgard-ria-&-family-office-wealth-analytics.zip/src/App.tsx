/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo, useState } from 'react';
import { NavTab, TopBar } from './components/Navigation/TopBar';
import { PortfolioOverview } from './components/Overview/PortfolioOverview';
import { PerformanceAttributionView } from './components/Attribution/PerformanceAttributionView';
import { RebalancingEngine } from './components/Rebalancing/RebalancingEngine';
import { ComplianceCommand } from './components/Compliance/ComplianceCommand';
import { QuarterlyReportingStudio } from './components/Reporting/QuarterlyReportingStudio';
import { INITIAL_AUDIT_LOG, INITIAL_HOUSEHOLDS } from './data/seedData';
import { AuditLogEntry, ClientHousehold, ComplianceRuleBreach, HoldingLot, TradeOrder } from './types/wealth';
import { auditHouseholdCompliance } from './utils/financialCalculations';

export default function App() {
  const [households, setHouseholds] = useState<ClientHousehold[]>(INITIAL_HOUSEHOLDS);
  const [selectedHouseholdId, setSelectedHouseholdId] = useState<string>('HH-STERLING-001');
  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [stagedOrders, setStagedOrders] = useState<TradeOrder[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOG);
  const [overrides, setOverrides] = useState<Record<string, { notes: string; by: string }>>({});

  const selectedHousehold = useMemo(() => {
    return households.find((h) => h.id === selectedHouseholdId) || households[0];
  }, [households, selectedHouseholdId]);

  // Dynamically audit compliance for selected household
  const activeBreaches = useMemo(() => {
    const rawBreaches = auditHouseholdCompliance(selectedHousehold);
    return rawBreaches.map((b) => {
      if (overrides[b.id]) {
        return {
          ...b,
          status: 'OVERRIDE_APPROVED' as const,
          overrideNotes: overrides[b.id].notes,
          overrideBy: overrides[b.id].by,
        };
      }
      return b;
    });
  }, [selectedHousehold, overrides]);

  const openBreachesCount = useMemo(() => {
    return activeBreaches.filter((b) => b.status === 'OPEN_BREACH').length;
  }, [activeBreaches]);

  // Execute trade batch from blotter into portfolio state
  const handleExecuteTradeBatch = (orders: TradeOrder[]) => {
    setHouseholds((prevHouseholds) =>
      prevHouseholds.map((h) => {
        if (h.id !== selectedHousehold.id) return h;

        const updatedHoldings = [...h.holdings];
        let cashDelta = 0;
        let realizedGainLossDelta = 0;

        orders.forEach((order) => {
          const existingLotIndex = updatedHoldings.findIndex((lot) => lot.ticker === order.ticker);

          if (order.action === 'SELL') {
            cashDelta += order.estimatedValue;
            if (existingLotIndex >= 0) {
              const lot = updatedHoldings[existingLotIndex];
              const remainingShares = Math.max(0, lot.shares - order.shares);
              const pnl = (order.price - lot.costBasisPerShare) * order.shares;
              realizedGainLossDelta += pnl;

              if (remainingShares === 0) {
                updatedHoldings.splice(existingLotIndex, 1);
              } else {
                updatedHoldings[existingLotIndex] = {
                  ...lot,
                  shares: remainingShares,
                  marketValue: remainingShares * lot.currentPrice,
                  unrealizedGainLoss: (lot.currentPrice - lot.costBasisPerShare) * remainingShares,
                  washSaleRestrictedUntil: pnl < 0 ? '2026-10-28' : undefined,
                };
              }
            }
          } else if (order.action === 'BUY') {
            cashDelta -= order.estimatedValue;
            if (existingLotIndex >= 0) {
              const lot = updatedHoldings[existingLotIndex];
              const newTotalShares = lot.shares + order.shares;
              const newTotalCost = lot.shares * lot.costBasisPerShare + order.estimatedValue;
              const newCostBasis = newTotalCost / newTotalShares;

              updatedHoldings[existingLotIndex] = {
                ...lot,
                shares: newTotalShares,
                costBasisPerShare: newCostBasis,
                marketValue: newTotalShares * lot.currentPrice,
                unrealizedGainLoss: (lot.currentPrice - newCostBasis) * newTotalShares,
              };
            } else {
              // Add new holding lot
              updatedHoldings.push({
                id: `LOT-${order.ticker}-${Date.now().toString().slice(-4)}`,
                ticker: order.ticker,
                name: order.name,
                category: order.category,
                shares: order.shares,
                costBasisPerShare: order.price,
                currentPrice: order.price,
                marketValue: order.estimatedValue,
                unrealizedGainLoss: 0,
                unrealizedGainLossPct: 0,
                acquisitionDate: '2026-09-28',
                isLongTerm: false,
                yieldPct: 1.5,
                expenseRatio: 0.05,
              });
            }
          }
        });

        const newTotalAUM = updatedHoldings.reduce((sum, lot) => sum + lot.marketValue, 0);

        return {
          ...h,
          totalAUM: newTotalAUM,
          cashBalance: h.cashBalance + cashDelta,
          holdings: updatedHoldings,
        };
      })
    );

    // Record immutable audit entry
    const newLog: AuditLogEntry = {
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' EDT',
      actor: 'Jonathan Vance, CFP, CFA',
      actorRole: 'Senior Portfolio Manager',
      action: 'REBALANCE_TRADE_BATCH_EXECUTION',
      regulatoryCode: 'SEC Rule 17a-4 / FIX Protocol Confirmation',
      details: `Executed ${orders.length} orders across ${selectedHousehold.custodian}. Securities: ${orders.map((o) => `${o.action} ${o.shares} ${o.ticker}`).join(', ')}.`,
      householdName: selectedHousehold.householdName,
    };

    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Quick action from holdings table to trigger tax loss harvest
  const handleQuickHarvestLot = (lot: HoldingLot) => {
    setActiveTab('rebalancing');
    const tlhOrder: TradeOrder = {
      id: `TLH-LOT-${lot.ticker}-${Date.now().toString().slice(-4)}`,
      ticker: lot.ticker,
      name: lot.name,
      category: lot.category,
      action: 'SELL',
      shares: lot.shares,
      price: lot.currentPrice,
      estimatedValue: lot.marketValue,
      orderType: 'LIMIT',
      targetAllocationDeltaPct: -((lot.marketValue / selectedHousehold.totalAUM) * 100),
      taxLotImpact: {
        type: 'TAX_LOSS_HARVEST',
        estimatedPnl: lot.unrealizedGainLoss,
      },
      washSaleWarning: Boolean(lot.washSaleRestrictedUntil && new Date(lot.washSaleRestrictedUntil) > new Date()),
      substituteProxyApplied: lot.substituteTicker,
      custodian: selectedHousehold.custodian,
      status: 'STAGED',
      stagedAt: new Date().toISOString(),
      reason: `Direct lot tax-loss harvest. Harvests $${Math.abs(lot.unrealizedGainLoss).toLocaleString()} in capital losses. ${lot.substituteTicker ? `Proxy reinvestment suggested: ${lot.substituteTicker}.` : ''}`,
    };
    setStagedOrders([tlhOrder]);
  };

  // Chief Compliance Officer supervisory override
  const handleResolveBreach = (breachId: string, notes: string) => {
    setOverrides((prev) => ({
      ...prev,
      [breachId]: { notes, by: 'Sarah Jenkins, CCO' },
    }));

    const newLog: AuditLogEntry = {
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' EDT',
      actor: 'Sarah Jenkins, CCO',
      actorRole: 'Chief Compliance Officer',
      action: 'SUPERVISORY_EXCEPTION_OVERRIDE',
      regulatoryCode: 'SEC Rule 206(4)-7 Mandate Review',
      details: `Authorized supervisory exception for breach #${breachId}. Rationale: "${notes}"`,
      householdName: selectedHousehold.householdName,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // Revalidate annual IPS attestation
  const handleRevalidateIPS = () => {
    const today = '2026-09-28';
    setHouseholds((prev) =>
      prev.map((h) =>
        h.id === selectedHousehold.id ? { ...h, lastIPSReviewDate: today } : h
      )
    );

    const newLog: AuditLogEntry = {
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' EDT',
      actor: 'Jonathan Vance, CFP, CFA',
      actorRole: 'Senior Portfolio Manager',
      action: 'ANNUAL_IPS_SUITABILITY_ATTESTATION',
      regulatoryCode: 'FINRA Rule 2111 & SEC Reg BI',
      details: `Formally re-attested Investment Policy Statement (IPS) and suitability parameters for ${selectedHousehold.householdName}. Next statutory review: 2027-09-28.`,
      householdName: selectedHousehold.householdName,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handleAddAuditEntry = (action: string, details: string) => {
    const newLog: AuditLogEntry = {
      id: `AUD-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' EDT',
      actor: 'Sarah Jenkins, CCO',
      actorRole: 'Chief Compliance Officer',
      action,
      regulatoryCode: 'SEC Rule 17a-4 Supervisory Inspection',
      details,
      householdName: selectedHousehold.householdName,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const handlePrintReport = () => {
    setActiveTab('reporting');
    setTimeout(() => {
      window.print();
    }, 150);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Strict 3-Zone Top Bar */}
      <TopBar
        currentTab={activeTab}
        onTabChange={setActiveTab}
        households={households}
        selectedHouseholdId={selectedHouseholdId}
        onHouseholdChange={setSelectedHouseholdId}
        openBreachCount={openBreachesCount}
        onPrintReport={handlePrintReport}
      />

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'overview' && (
          <PortfolioOverview
            household={selectedHousehold}
            openBreachesCount={openBreachesCount}
            onNavigateToTab={setActiveTab}
            onQuickHarvestLot={handleQuickHarvestLot}
          />
        )}

        {activeTab === 'attribution' && (
          <PerformanceAttributionView household={selectedHousehold} />
        )}

        {activeTab === 'rebalancing' && (
          <RebalancingEngine
            household={selectedHousehold}
            onExecuteTradeBatch={handleExecuteTradeBatch}
            stagedOrders={stagedOrders}
            setStagedOrders={setStagedOrders}
          />
        )}

        {activeTab === 'compliance' && (
          <ComplianceCommand
            household={selectedHousehold}
            breaches={activeBreaches}
            auditLogs={auditLogs}
            onResolveBreach={handleResolveBreach}
            onAddAuditEntry={handleAddAuditEntry}
            onRevalidateIPS={handleRevalidateIPS}
          />
        )}

        {activeTab === 'reporting' && (
          <QuarterlyReportingStudio
            household={selectedHousehold}
            onPrintReport={handlePrintReport}
          />
        )}
      </main>

      {/* Institutional Quiet Footer */}
      <footer className="no-print border-t border-slate-900 bg-slate-950 text-xs text-slate-500 py-6 px-6">
        <div className="max-w-[1440px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">Aethelgard Wealth Analytics</span>
            <span>·</span>
            <span>SEC CRD #849102 · Registered Investment Adviser (RIA)</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500 text-[11px]">
            <span>Form ADV Part 2A &amp; 2B on File</span>
            <span>·</span>
            <span>GIPS Performance Verification</span>
            <span>·</span>
            <span>SEC Rule 17a-4 Books &amp; Records Archive</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
