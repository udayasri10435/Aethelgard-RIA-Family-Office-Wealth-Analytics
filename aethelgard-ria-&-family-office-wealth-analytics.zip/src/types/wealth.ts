export type EntityType = 
  | 'Dynasty Trust'
  | 'Private Foundation 501(c)(3)'
  | 'Family Office Corporate HoldCo'
  | 'High Net Worth Joint Account'
  | 'Revocable Living Trust';

export type Custodian = 
  | 'Charles Schwab Institutional'
  | 'Fidelity Institutional (IWS)'
  | 'BNY Mellon Pershing';

export type RiskMandate = 
  | 'Capital Preservation'
  | 'Conservative Growth'
  | 'Moderate Balanced'
  | 'Long-Term Capital Growth'
  | 'Aggressive Global Endowment';

export type AssetCategory = 
  | 'US Large Cap Equity'
  | 'US Small/Mid Cap'
  | 'International Developed Equity'
  | 'Emerging Markets Equity'
  | 'Core Fixed Income'
  | 'Municipal Bonds'
  | 'Liquid Treasuries & Cash'
  | 'Private Real Assets & Alts';

export interface HoldingLot {
  id: string;
  ticker: string;
  name: string;
  category: AssetCategory;
  shares: number;
  costBasisPerShare: number;
  currentPrice: number;
  marketValue: number;
  unrealizedGainLoss: number;
  unrealizedGainLossPct: number;
  acquisitionDate: string; // YYYY-MM-DD
  isLongTerm: boolean; // held > 365 days
  washSaleRestrictedUntil?: string; // date if sold at loss within 30 days
  substituteTicker?: string; // e.g. VOO -> SCHX or IVV
  yieldPct: number;
  expenseRatio: number;
}

export interface TargetAllocation {
  category: AssetCategory;
  targetPct: number;
  minTolerancePct: number;
  maxTolerancePct: number;
  benchmarkIndex: string;
}

export interface ClientHousehold {
  id: string;
  householdName: string;
  primaryContact: string;
  entityType: EntityType;
  custodian: Custodian;
  accountNumber: string;
  inceptionDate: string;
  advisorName: string;
  riskMandate: RiskMandate;
  totalAUM: number;
  cashBalance: number;
  unrealizedGainsTotal: number;
  unrealizedLossesTotal: number;
  ytdReturnPct: number;
  oneYearReturnPct: number;
  threeYearReturnPct: number;
  fiveYearReturnPct: number;
  twrReturnPct: number;
  mwrReturnPct: number;
  annualFeeBps: number; // basis points, e.g. 65 bps = 0.65%
  lastIPSReviewDate: string;
  holdings: HoldingLot[];
  targets: TargetAllocation[];
}

export interface BenchmarkMetrics {
  name: string;
  code: string;
  ytdReturn: number;
  oneYearReturn: number;
  threeYearReturn: number;
  volatility: number;
  sharpe: number;
}

export interface BrinsonAttributionRow {
  category: AssetCategory;
  portfolioWeight: number; // w_i
  benchmarkWeight: number; // W_i
  portfolioReturn: number; // r_i
  benchmarkReturn: number; // R_i
  allocationEffect: number; // (w_i - W_i) * (R_i - R_b)
  selectionEffect: number;  // W_i * (r_i - R_i)
  interactionEffect: number;// (w_i - W_i) * (r_i - R_i)
  totalEffect: number;      // sum of above
}

export interface RiskAdjustedAnalytics {
  portfolioTWR: number;
  benchmarkReturn: number;
  excessReturn: number;
  annualizedSharpeRatio: number;
  annualizedSortinoRatio: number;
  jensensAlpha: number;
  beta: number;
  trackingError: number;
  informationRatio: number;
  maxDrawdown: number;
  calmarRatio: number;
  standardDeviation: number;
  upCaptureRatio: number;
  downCaptureRatio: number;
}

export interface HistoricalPerformancePoint {
  date: string;
  portfolioValue: number;
  portfolioCumulativePct: number;
  benchmarkCumulativePct: number;
  secondaryBenchmarkPct: number;
  drawdownPct: number;
}

export interface TradeOrder {
  id: string;
  ticker: string;
  name: string;
  category: AssetCategory;
  action: 'BUY' | 'SELL';
  shares: number;
  price: number;
  estimatedValue: number;
  orderType: 'LIMIT' | 'MARKET';
  targetAllocationDeltaPct: number;
  taxLotImpact?: {
    type: 'LONG_TERM_GAIN' | 'SHORT_TERM_GAIN' | 'TAX_LOSS_HARVEST';
    estimatedPnl: number;
  };
  washSaleWarning: boolean;
  substituteProxyApplied?: string;
  custodian: Custodian;
  status: 'STAGED' | 'APPROVED' | 'EXECUTED' | 'CANCELLED';
  stagedAt: string;
  reason: string;
}

export interface ComplianceRuleBreach {
  id: string;
  ruleCode: 'SEC_IPS_CONCENTRATION' | 'FINRA_SUITABILITY_MISMATCH' | 'LIQUIDITY_BUFFER_BREACH' | 'UNAPPROVED_ASSET_CLASS' | 'WASH_SALE_TRIGGER' | 'ADV_FEE_DISCREPANCY';
  severity: 'HIGH_ALERT' | 'MEDIUM_WARNING' | 'INFORMATIONAL';
  title: string;
  description: string;
  regulatoryReference: string; // e.g. 'SEC Rule 206(4)-7 / Form ADV Item 8'
  householdId: string;
  detectedAt: string;
  status: 'OPEN_BREACH' | 'OVERRIDE_APPROVED' | 'RESOLVED';
  overrideNotes?: string;
  overrideBy?: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: 'Chief Compliance Officer' | 'Senior Portfolio Manager' | 'Operations Trader';
  action: string;
  regulatoryCode: string; // e.g. 'SEC Rule 17a-4'
  details: string;
  householdName: string;
}
